#pragma once
#include <juce_audio_utils/juce_audio_utils.h>

// TaLaVie 808 : basse 808 monophonique (sinus + chute de hauteur + slide + saturation)
class TaLaVie808Processor : public juce::AudioProcessor
{
public:
    TaLaVie808Processor();

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported (const BusesLayout& l) const override
    { return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo(); }

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "TaLaVie 808"; }
    bool acceptsMidi() const override  { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 6.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void noteOn (int note, float velocity, bool slideAllowed);
    void noteOff (int note);

    double sr = 44100.0;
    std::vector<int> held;                  // notes tenues (la dernière = la note jouée)
    double phase = 0.0;
    float  curFreq = 0.f, targetFreq = 0.f;
    float  ampEnv = 0.f, pitchEnv = 0.f, clickEnv = 0.f, lpState = 0.f, vel = 1.f;
    bool   gate = false, attacking = false;
    juce::Random rng;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TaLaVie808Processor)
};
