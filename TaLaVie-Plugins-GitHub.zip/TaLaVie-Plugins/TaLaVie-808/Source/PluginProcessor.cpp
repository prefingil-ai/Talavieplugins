#include "PluginProcessor.h"
#include <algorithm>

juce::AudioProcessorValueTreeState::ParameterLayout TaLaVie808Processor::createLayout()
{
    using P = juce::AudioParameterFloat;
    using R = juce::NormalisableRange<float>;
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<P> ("decay",     "Longueur (s)",       R (0.2f, 6.f, 0.01f, 0.6f), 1.8f));
    p.push_back (std::make_unique<P> ("release",   "Release (s)",        R (0.02f, 1.f, 0.01f, 0.5f), 0.12f));
    p.push_back (std::make_unique<P> ("punch",     "Punch (chute)",      R (0.f, 4.f, 0.01f), 1.5f));
    p.push_back (std::make_unique<P> ("punchTime", "Punch duree (ms)",   R (5.f, 120.f, 0.1f), 30.f));
    p.push_back (std::make_unique<P> ("glide",     "Slide (ms)",         R (0.f, 400.f, 1.f), 80.f));
    p.push_back (std::make_unique<P> ("drive",     "Saturation",         R (0.f, 1.f, 0.01f), 0.45f));
    p.push_back (std::make_unique<P> ("click",     "Click",              R (0.f, 1.f, 0.01f), 0.25f));
    p.push_back (std::make_unique<P> ("tone",      "Tone (Hz)",          R (200.f, 12000.f, 1.f, 0.4f), 3500.f));
    p.push_back (std::make_unique<P> ("volume",    "Volume",             R (0.f, 1.2f, 0.01f), 0.8f));
    return { p.begin(), p.end() };
}

TaLaVie808Processor::TaLaVie808Processor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
}

void TaLaVie808Processor::prepareToPlay (double sampleRate, int)
{
    sr = sampleRate;
    held.clear();
    gate = attacking = false;
    ampEnv = pitchEnv = clickEnv = lpState = 0.f;
}

void TaLaVie808Processor::noteOn (int note, float velocity, bool slideAllowed)
{
    const float f = (float) juce::MidiMessage::getMidiNoteInHertz (note);
    const bool slide = gate && ampEnv > 0.02f && slideAllowed;   // notes qui se chevauchent = slide legato

    held.erase (std::remove (held.begin(), held.end(), note), held.end());
    held.push_back (note);
    targetFreq = f;
    vel = velocity;

    if (! slide)                       // nouvelle attaque : punch + click
    {
        curFreq = f;
        pitchEnv = 1.f;
        clickEnv = 1.f;
        attacking = true;
    }
    gate = true;
}

void TaLaVie808Processor::noteOff (int note)
{
    held.erase (std::remove (held.begin(), held.end(), note), held.end());
    if (held.empty()) gate = false;
    else              targetFreq = (float) juce::MidiMessage::getMidiNoteInHertz (held.back());
}

void TaLaVie808Processor::processBlock (juce::AudioBuffer<float>& buf, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buf.clear();

    auto val = [this] (const char* id) { return apvts.getRawParameterValue (id)->load(); };

    const float decay     = val ("decay"), release = val ("release");
    const float punch     = val ("punch"), punchT  = val ("punchTime") / 1000.f;
    const float glideSec  = val ("glide") / 1000.f;
    const float drive     = val ("drive"), click   = val ("click");
    const float tone      = val ("tone"),  volume  = val ("volume");

    const float decayCoef = (float) std::pow (0.001, 1.0 / (sr * decay));
    const float relCoef   = (float) std::pow (0.001, 1.0 / (sr * release));
    const float pitchCoef = (float) std::exp (-1.0 / (sr * punchT));
    const float glideCoef = glideSec > 0.f ? (float) (1.0 - std::exp (-1.0 / (sr * glideSec))) : 1.f;
    const float clickCoef = (float) std::exp (-1.0 / (sr * 0.004));
    const float toneCoef  = (float) (1.0 - std::exp (-juce::MathConstants<double>::twoPi * tone / sr));
    const float atkInc    = (float) (1.0 / (0.0015 * sr));
    const float k         = 1.f + drive * 9.f;
    const float kNorm     = std::tanh (k);

    auto it = midi.begin();
    const int n = buf.getNumSamples();
    auto* L = buf.getWritePointer (0);
    auto* R = buf.getWritePointer (1);

    for (int i = 0; i < n; ++i)
    {
        while (it != midi.end() && (*it).samplePosition <= i)
        {
            const auto m = (*it).getMessage();
            if      (m.isNoteOn())                          noteOn (m.getNoteNumber(), m.getFloatVelocity(), glideSec > 0.f);
            else if (m.isNoteOff())                         noteOff (m.getNoteNumber());
            else if (m.isAllNotesOff() || m.isAllSoundOff()) { held.clear(); gate = attacking = false; ampEnv = 0.f; }
            ++it;
        }

        if (ampEnv < 1.0e-5f && ! gate && ! attacking) { L[i] = R[i] = 0.f; continue; }

        // Hauteur : slide + chute de hauteur au début (le « thump »)
        curFreq += (targetFreq - curFreq) * glideCoef;
        phase   += juce::MathConstants<double>::twoPi * curFreq * (1.f + punch * pitchEnv) / sr;
        if (phase > juce::MathConstants<double>::twoPi) phase -= juce::MathConstants<double>::twoPi;
        pitchEnv *= pitchCoef;

        // Volume : attaque très courte, longue descente, release à la fin de la note
        if (attacking) { ampEnv += atkInc; if (ampEnv >= 1.f) { ampEnv = 1.f; attacking = false; } }
        else if (gate)  ampEnv *= decayCoef;
        else            ampEnv *= relCoef;

        float s = (float) std::sin (phase) * ampEnv * (0.4f + 0.6f * vel);
        s = std::tanh (k * s) / kNorm;                        // saturation : harmoniques audibles sur petits haut-parleurs
        clickEnv *= clickCoef;
        s += click * clickEnv * (rng.nextFloat() * 2.f - 1.f) * 0.5f;
        lpState += toneCoef * (s - lpState);                   // tone (passe-bas)

        const float o = juce::jlimit (-1.f, 1.f, lpState * volume);
        L[i] = R[i] = o;                                       // 808 = mono, au centre
    }
}

juce::AudioProcessorEditor* TaLaVie808Processor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

void TaLaVie808Processor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, dest);
}

void TaLaVie808Processor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new TaLaVie808Processor(); }
