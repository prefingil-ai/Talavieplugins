# TaLaVie 808 — plugin VST3 (basse 808 afrobeat)

## Compiler sur Windows
1. Installer Visual Studio 2022 Community (« Développement Desktop en C++ ») et CMake.
2. Dans « x64 Native Tools Command Prompt for VS 2022 », dans ce dossier :
       cmake -B build -G "Visual Studio 17 2022"
       cmake --build build --config Release
3. Le plugin : build\TaLaVie808_artefacts\Release\VST3\TaLaVie 808.vst3
4. Copier dans C:\Program Files\Common Files\VST3, puis dans FL Studio : Rechercher plugins.

## Réglages
- Longueur : durée de la note (1,8 s par défaut). Release : arrêt quand on lâche la touche.
- Punch / Punch durée : le « thump » du début (chute de hauteur).
- Slide : notes qui se chevauchent = glissando entre elles (typique afrobeat/trap). 0 = désactivé.
- Saturation : rend la 808 audible sur téléphone et petites enceintes.
- Click, Tone, Volume.

Astuce : joue dans les octaves C1 à C2 (notes graves) ; la 808 est monophonique (une note à la fois).
