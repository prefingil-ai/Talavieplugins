# TaLaVie Plugins — compilation automatique sur GitHub

1. Sur github.com : New repository, nom « talavie-plugins », en Privé.
2. Dans le dépôt : Add file > Upload files, glisse TOUT le contenu de ce dossier
   (les 3 dossiers de plugins + le dossier .github + .gitignore), puis Commit.
3. Onglet Actions : le build démarre tout seul (10 à 20 minutes). Sinon : « Compiler les plugins TaLaVie » > Run workflow.
4. Quand c'est vert : ouvre l'exécution, descends à « Artifacts », télécharge
   TaLaVie-808-VST3, TaLaVie-Guitare-VST3, TaLaVie-Pads-VST3.
5. Dézippe, copie le .vst3 dans C:\Program Files\Common Files\VST3, puis FL Studio : Options > Gestionnaire de fichiers > Rechercher plugins.
